encrypted_data = xor_encrypt(original, key)
